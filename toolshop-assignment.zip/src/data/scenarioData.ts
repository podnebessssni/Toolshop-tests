export type ScenarioName =
  | "approved"
  | "declined"
  | "serverError"
  | "slowDecision";

export interface ScenarioData {
  consumer: { email: string; firstName: string; lastName: string };
  product: { id: string; name: string };
  payment: { method: string; installments: string };
  expected: {
    status: number;
    body: { message?: string; error?: string };
    uiMessage: string;
  }
  delayMs: number;
}

export function scenarioData(scenario: ScenarioName): ScenarioData {
  return new ScenarioDataFactory().create(scenario);
}

class ScenarioDataFactory {
  private readonly availableProducts = [
    { id: "01M51R65WHYR2BZRFZKS8F3FAT", name: "Combination Pliers" },
    { id: "01M51R65WPWGHGGM8PK9K9WNQG", name: "Pliers" },
    { id: "01M51R65WTAEHPH6BCYM9X9TW9", name: "Bolt Cutters" },
    { id: "01M51R65X363RH19SYMCXXQH9Y", name: "Slip Joint Pliers" },
    { id: "01M51R65X6TF1DD8RKHCG9T9QV", name: "Claw Hammer with Shock Reduction Grip" },
    { id: "01M51R65X97R4Q2MPPV315H4ST", name: "Hammer" },
    { id: "01M51R65XB2690KXP4MWARSV71", name: "Claw Hammer" },
  ] as const;

  create(scenario: ScenarioName): ScenarioData {
    return this.templateFor(scenario);
  }

  private templateFor(scenario: ScenarioName): ScenarioData {
    switch (scenario) {
      case "approved":
        return this.approvedTemplate();
      case "declined":
        return this.declinedTemplate();
      case "serverError":
        return this.serverErrorTemplate();
      case "slowDecision":
        return this.slowDecisionTemplate();
    }
  };

  private baseData(): Omit<ScenarioData, "expected" | "delayMs"> {
    // Pin consumer/payment data, but pick a stocked product randomly to vary cart coverage; CheckoutFunctions includes its name in the report step.
    const productIndex = Math.floor(Math.random() * this.availableProducts.length);
    return {
      consumer: {
        email: "toolshop.qa@example.test",
        firstName: "Taylor",
        lastName: "Example",
      },
      product: this.availableProducts[productIndex],
      payment: { method: "buy-now-pay-later", installments: "3" },
    };
  }

  private approvedTemplate(): ScenarioData {
    return {
      ...this.baseData(),
      expected: {
        status: 200,
        body: { message: "Payment was successful" },
        uiMessage: "Payment was successful",
      },
      delayMs: 0,
    };
  }

  private declinedTemplate(): ScenarioData {
    return {
      ...this.baseData(),
      expected: {
        status: 402,
        body: { error: "Financing declined" },
        uiMessage: "Financing declined",
      },
      delayMs: 0,
    };
  }

  private serverErrorTemplate(): ScenarioData {
    return {
      ...this.baseData(),
      expected: {
        status: 500,
        body: { error: "Payment service unavailable" },
        uiMessage: "Payment service unavailable",
      },
      delayMs: 0,
    };
  }

  private slowDecisionTemplate(): ScenarioData {
    return {
      ...this.baseData(),
      expected: {
        status: 200,
        body: { message: "Payment was successful" },
        uiMessage: "Payment was successful",
      },
      delayMs: 2500,
    };
  }
}
